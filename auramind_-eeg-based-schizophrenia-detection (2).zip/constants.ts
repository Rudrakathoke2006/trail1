
import type { Patient } from './types';
import React from 'react';

import { CognitiveTestsIcon } from './components/icons/CognitiveTestsIcon';
import { SleepAnalysisIcon } from './components/icons/SleepAnalysisIcon';
import { TreatmentPredictorIcon } from './components/icons/TreatmentPredictorIcon';
import { StressMonitorIcon } from './components/icons/StressMonitorIcon';
import { GeneticRiskIcon } from './components/icons/GeneticRiskIcon';
import { SpeechAnalysisIcon } from './components/icons/SpeechAnalysisIcon';
import { SocialMetricsIcon } from './components/icons/SocialMetricsIcon';
import { MedTrackerIcon } from './components/icons/MedTrackerIcon';
import { CircadianHealthIcon } from './components/icons/CircadianHealthIcon';
import { VRTherapyIcon } from './components/icons/VRTherapyIcon';
import { NutritionImpactIcon } from './components/icons/NutritionImpactIcon';
import { EnvironmentScanIcon } from './components/icons/EnvironmentScanIcon';
import { PeerAnalysisIcon } from './components/icons/PeerAnalysisIcon';
import { CrisisAlertIcon } from './components/icons/CrisisAlertIcon';
import { RemoteConsultIcon } from './components/icons/RemoteConsultIcon';
import { ResearchPortalIcon } from './components/icons/ResearchPortalIcon';
import { EmergencyAlertIcon } from './components/icons/EmergencyAlertIcon';


export const PATIENTS: Patient[] = [
  { id: 'p001', name: 'John Doe', age: 28, gender: 'Male', status: 'Stable', lastCheckup: '2023-10-15' },
  { id: 'p002', name: 'Jane Smith', age: 34, gender: 'Female', status: 'At Risk', lastCheckup: '2023-11-01' },
  { id: 'p003', name: 'Robert Johnson', age: 45, gender: 'Male', status: 'Needs Review', lastCheckup: '2023-09-22' },
  { id: 'p004', name: 'Emily Davis', age: 22, gender: 'Female', status: 'Stable', lastCheckup: '2023-11-10' },
  { id: 'p005', name: 'Michael Brown', age: 51, gender: 'Male', status: 'Stable', lastCheckup: '2023-08-05' },
];

export const EEG_CHANNELS: (keyof Omit<import('./types').EEGDataPoint, 'time'>)[] = ['Fp1', 'Fp2', 'C3', 'C4', 'Pz', 'O1'];

export const EEG_CHANNEL_COLORS: { [key: string]: string } = {
  Fp1: '#8884d8',
  Fp2: '#82ca9d',
  C3: '#ffc658',
  C4: '#ff8042',
  Pz: '#0088FE',
  O1: '#00C49F',
};

interface AdvancedFeature {
  id: string;
  name: string;
  Icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

export const ADVANCED_FEATURES: AdvancedFeature[] = [
  { id: 'cognitive', name: 'Cognitive Tests', Icon: CognitiveTestsIcon },
  { id: 'sleep', name: 'Sleep Analysis', Icon: SleepAnalysisIcon },
  { id: 'treatment', name: 'Treatment Predictor', Icon: TreatmentPredictorIcon },
  { id: 'stress', name: 'Stress Monitor', Icon: StressMonitorIcon },
  { id: 'genetic', name: 'Genetic Risk', Icon: GeneticRiskIcon },
  { id: 'speech', name: 'Speech Analysis', Icon: SpeechAnalysisIcon },
  { id: 'social', name: 'Social Metrics', Icon: SocialMetricsIcon },
  { id: 'med_tracker', name: 'Med Tracker', Icon: MedTrackerIcon },
  { id: 'circadian', name: 'Circadian Health', Icon: CircadianHealthIcon },
  { id: 'vr_therapy', name: 'VR Therapy', Icon: VRTherapyIcon },
  { id: 'nutrition', name: 'Nutrition Impact', Icon: NutritionImpactIcon },
  { id: 'environment', name: 'Environment Scan', Icon: EnvironmentScanIcon },
  { id: 'peer', name: 'Peer Analysis', Icon: PeerAnalysisIcon },
  { id: 'crisis', name: 'Crisis Alert', Icon: CrisisAlertIcon },
  { id: 'telemedicine', name: 'Remote Consult', Icon: RemoteConsultIcon },
  { id: 'research', name: 'Research Portal', Icon: ResearchPortalIcon },
  { id: 'emergency', name: 'Emergency Alert', Icon: EmergencyAlertIcon },
];
