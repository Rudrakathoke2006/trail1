
import React, { useState, useMemo } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { BrainIcon } from './components/icons/BrainIcon';
import type { Patient } from './types';
import { PATIENTS } from './constants';

const App: React.FC = () => {
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);

  const handleSelectPatient = (patient: Patient) => {
    setSelectedPatient(patient);
  };
  
  const WelcomeScreen = () => (
    <div className="flex flex-col items-center justify-center h-full text-center text-gray-500">
      <BrainIcon className="w-24 h-24 mb-4 text-gray-300" />
      <h2 className="text-2xl font-semibold">Welcome to AuraMind</h2>
      <p className="mt-2 max-w-md">Please select a patient from the sidebar to view their EEG data and perform an analysis.</p>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-100 font-sans">
      <Sidebar 
        patients={PATIENTS} 
        selectedPatient={selectedPatient} 
        onSelectPatient={handleSelectPatient} 
      />
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white shadow-sm p-4 z-10">
          <h1 className="text-2xl font-bold text-text-primary flex items-center">
            <BrainIcon className="w-8 h-8 mr-3 text-brand-primary" />
            AuraMind: EEG Analysis Dashboard
          </h1>
        </header>
        <div className="flex-1 p-6 overflow-auto">
          {selectedPatient ? (
            <Dashboard key={selectedPatient.id} patient={selectedPatient} />
          ) : (
            <WelcomeScreen />
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
